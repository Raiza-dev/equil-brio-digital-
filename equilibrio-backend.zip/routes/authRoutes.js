const express = require("express");
const router = express.Router();
const Institution = require("../models/Institution");
const bcrypt = require("bcryptjs");

// Register
router.post("/register", async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ error: "Dados incompletos" });

    const exists = await Institution.findOne({ email });
    if (exists) return res.status(400).json({ error: "Email já registrado" });

    const hashed = await bcrypt.hash(password, 10);
    const inst = await Institution.create({ name, email, phone, password: hashed });
    return res.json({ status: "ok", id: inst._id, name: inst.name });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro no servidor" });
  }
});

// Login (simples)
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await Institution.findOne({ email });
    if (!user) return res.status(400).json({ error: "Usuário não encontrado" });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: "Senha incorreta" });

    res.json({ status: "ok", userId: user._id, name: user.name, email: user.email });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro no servidor" });
  }
});

module.exports = router;
