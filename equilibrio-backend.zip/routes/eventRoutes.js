const express = require("express");
const router = express.Router();
const Event = require("../models/Event");

// Criar evento
router.post("/create", async (req, res) => {
  try {
    const ev = await Event.create(req.body);
    res.json(ev);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao criar evento" });
  }
});

// Listar eventos
router.get("/", async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 });
    res.json(events);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao buscar eventos" });
  }
});

module.exports = router;
