const express = require("express");
const router = express.Router();
const Topic = require("../models/Topic");

router.post("/create", async (req, res) => {
  try {
    const topic = await Topic.create(req.body);
    res.json(topic);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao criar tópico" });
  }
});

router.get("/", async (req, res) => {
  try {
    const topics = await Topic.find().sort({ createdAt: -1 });
    res.json(topics);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Erro ao buscar tópicos" });
  }
});

module.exports = router;
